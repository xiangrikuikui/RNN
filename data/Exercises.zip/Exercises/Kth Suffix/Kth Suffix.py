# -*- coding: utf-8 -*-
"""
Created on Fri Aug 31 11:57:32 2018

@author: samsung
"""

"""
There is a character stream consisting oflower case English alphabets. When the length of the stream is n, the number ofsuffixes is equivalent to the length of the stream. In the figure below, thestream “monster” has suffixes shown on left and when they are sorted inlexicographical order,   the elements will be sorted as in the figureon the right. 
  
 【15】
Among the suffixes of thestream “monster”, the suffix that comes fourth is “onster”. 

Given the value of k and a characterstream are given, find the kth suffix in lexicographical order and print it. 


[Input]
10 test cases are giventhrough standard input. 
Each test case consists oftwo lines; the first line has an integer k and the next line has a characterstream composed of lower case English alphabets. 

[Output]
You need to print out “#C”in the first line of each test case with C being the case number. Leave a blankspace in the same line, and print the kth substream in lexicographical order.If there is no kth substream, print “none”. 

[Input/output example]
Input (only 2 inputexamples are shown and the actual input has a maximum of 40 test data.)

4          ← value of K, test case 1 starts
monster   ← character stream
9          ← value of K, test case 2 starts
sesquipedalian   ← character stream
18
supercalifragilisticexpialidociou
. . .

Output
#1 onster
#2 n
#3 ious
. . .

