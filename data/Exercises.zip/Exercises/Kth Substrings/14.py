# -*- coding: utf-8 -*-
"""
Created on Fri Aug 31 11:58:28 2018

@author: samsung
"""

"""
Assume that we have a string in English lower case. We can obtain its substrings by picking two positions and concatenating consecutive characters between them. 
If two positions are the same, we get a substring of length 1. For example, all the substrings of a string love are l, o, v, e, lo, ov, ve, lov, ove, and love. 
Also, all the substrings of another string food are f, o, d, fo, oo, od, foo, ood, and food. Note that we consider duplicated substrings as one. 
Now consider the problem of sorting them in the lexicographical order. We compare two different strings from left to right.
Once we find a difference, the one with the character which appears before in the alphabetical order precedes the other. 
For example, we show the lexicographical sorting of two strings love and food. 
order	substrings of love	substrings of food
1	e	d
2	l	f
3	lo	fo
4	lov	foo
5	love	food
6	o	o
7	ov	od
8	ove	oo
9	v	ood
10	ve	
Write a program that, given the text and an integer K, prints the substring whose lexicographical rank is K. Check the input/output conditions below thoroughly.
[Input]
T test cases are given continuously as standard input. 

Each test case starts with a line containing one integer K, followed by another line containing a string in English lower case. 
[Output]
For each test case, you should print “#C” in the first line where C is the case number. Then, in the same line after a space there should be the string whose lexicographic order is K. 
If Kth string does not exist, print “none”. 
[Input Output Example]
Input 
2			← Value of T, the number of test cases
7			← Value of K, Start of Case 1
love 
10 ← Value of K, Start of Case 2
food
Output
#1 ov
#2 none

