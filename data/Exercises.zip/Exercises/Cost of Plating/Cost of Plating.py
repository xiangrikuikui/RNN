"""
Master Artisan Kim who collects damaged metal plates andre-plates the damaged areas to sell them wants to minimize the cost needed forplating. The plated metal plate is square-shaped and is divided into small,square-shaped sections. There may be damaged area in each section. The locationof each block is represented as (row, column). 
###1### 
In the figureabove, the 5 x 5 metal plate(left) has 5 damaged areas and their locations areas follows. 
(2, 3), (3, 2), (3, 3), (3, 4), (4, 3)
 
In the figureabove, the 10 x 10 metal plate (right) has 26 damaged areas. The cost forplating processing is determined by the price of plating film. 
The damagedareas will be re-plated with the plating film, but the plating film supplierpredetermined the specification of the film as squares of three sizes inaccordance with the size of the section and the bigger the size is, the smallerthe unit price is. 
Therefore, since the goal is to minimize the total cost ofplating film, it is important to set location and coverage of the film so thatone film could cover section(s) where damaged areas are concentrated as widelyas possible. 
The plating film covers the square sections as much as thecoverage from the upper-left side where the plating film is attached andprocessed to lower-right side. In other words, it is not wrong plating filmoverlaps in a damaged area. 
Plating according to the location and coverage ofone plating film can be represented as follows. 
###2###
###3### 
 
In the formulaabove, the floor() function means to truncate decimal point. According to theformula above, the cost of plating processing with coverage 1 is 2; the cost ofplating with coverage 2 is 4; the cost for coverage 3 is 7; the cost the coverage 4 requires 11.
Let’s compute thecost for plating processing so that the all damaged areas can be plated withthe minimum plating processing cost. The smaller the total cost of plating is,the higher you will score in the test. 
 
[Scoring criteria]
Each Testcase will beallocated 10 points
[Test case]
Test cases are divided into 5 groups by the width of the metal plate. 
	Group1	Group2	Group3	Group4	Group5
Width of metal plate	1 ~ 10	11 ~ 20	21 ~ 40	41 ~ 60	61 ~ 100


[Input]
Ttest cases are given continuously through standard input. 
The very first line has has the total number oftest cases. 
The first line ofeach test case has S, the width of the metal plate(1≤S≤100). Themetal plate has S*S sections. In the next line, the number of damaged areas, N,is given (1≤N≤10000). Location(row and column) of the section(s) in which damaged areas exist comes in thenext line. 
[Input example]
2 ← T : total number of test cases
5 ← S : width of metal plate, test case #1 starts
5 ← N : total number of damaged areas
2 3 3 2 3 3 3 4 4 3 ← (row, column) : location of section(s) where damaged areas exist
10 ← S : width of metal plate, test case #2 starts
11
2 3 2 4 3 3 3 4 7 3 7 4 8 2 8 3 9 2 9 3 9 4

[Output]
Print answers for each of the test casesin order through standard output, and print “#C” at start of line for each testcase with C being test case number. Leavea blank space, and print the number of plating processing. Leave another blankspace and print all locations (row, column) and coverages of each plating processing. 

[Output example]
#1 1 2 2 3 ← number of plating: 1, location of plating: (2,2), coverage of plating: 3
#2 2 2 3 2 7 2 3 ← number of plating: 2, location of first plating: (2,3), coverage of plating: 2, location of second plating: (7, 2), coverage of plating: 3

[Explanation]

"""