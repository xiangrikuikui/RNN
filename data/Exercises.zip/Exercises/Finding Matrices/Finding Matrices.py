"""
The UNChemical Weapons Inspectors investigate a warehouse storing some chemicalsubstances for manufacturing deadly chemical weapons. There are n2 chemical containers thatare arranged in an nxn array. The UN Chemical Weapons Inspectorslook into each chemical container in the warehouse and store the informationinto a 2-dimensional array; ‘0’ for an empty container, and ‘k’ for a container holding the chemicalsubstance type k, where k = 1, 2, 3, …, 9. The following figureshows an example of the 9x9 array obtained from a warehouse. 
 
###pic### 
 
 
The UNChemical Weapons Inspectors found the following three facts from the chemical substancesin the warehouse. 
1.     The containersholding chemical substances form a rectangular shape. There is no emptycontainer in the rectangle. For example, there are three rectangles of thecontainers holding chemical substances—A, B, and C—in the above figure. 
2.     The dimension (thenumber of rows x the number of columns) of a rectangle of the containersholding chemical substances is not the same as that of any other rectangle. Forexample, A is 3x4, B is 2x3, and C is 4x5 in the above figure.
3.     There are emptycontainers between two rectangles of the containers holding chemicalsubstances. For example, you can find the empty containers (‘0’ elements)between A and B as well as B and C. Note that there may not be an emptycontainer between two rectangles that are adjacent diagonally; for example,there is no empty container between A and C in the figure.
  
 
The UNChemical Weapons Inspectors is about to embark on finding matrices (rectanglesof the containers holding chemical substances) in a 2-dimensional array in whichthe containers of the warehouse are arranged. To help accelerate theinvestigations, write a program that prints the information of the matricesfound. 

[Constraints]
N is not greater than 100. 
The number of rows of submatricesis different, and the number of columns of the submatrices is also different.  
For example, when threesubmatrices (A(3x4), B(2x3), C(4x5)) are extracted, the number of rows of each submatrix is different as 3, 2, 4.  
Likewise, the number of columnsof each submatrix is different as 4, 3, 5. 
Test cases are composed of several groups as follows. 
Group 1. n <= 10, number of sub matrix: 5 or less
Group 2. n <= 40, 5 < sub matrix <= 10 
Group 3. 40 < n <= 80, 5 < sub matrix <= 10 
Group 4. 40 < n <= 80, 10 < sub matrix <= 15 
Group 5. 80 < n <=100, 15 < sub matrix <= 20
  

[Input]
In thefirst line, the number of test cases is given. Each test case consists of (n+1) lines; the first line has apositive integer n and the next n lines have an nxn matrix row-by-row,one row per line.
 
[Output]
Print answers for each of the test cases.Start each line with ‘#x’, leave a blank space and print out the number of submatricesextracted in the matrix given and then the size of row and column of thematrices. Print the numbers in order of small to large. ‘Size’ means the resultof multiplying row and column. For example, the size of the matrix 3x4 is 3*4 = 12. 

[Input/outputexample]
Input
10                              <- the number of test cases
9                             <- test case #1
1 1 3 2 0 0 0 0 0 
3 2 5 2 0 0 0 0 0
2 3 3 1 0 0 0 0 0
0 0 0 0 4 5 5 3 1               <- 9x9 matrix in row-by-row
1 2 5 0 3 6 4 2 1           
2 3 6 0 2 1 1 4 2
0 0 0 0 4 2 3 1 1
0 0 0 0 0 0 0 0 0
0 0 0 0 0 0 0 0 0
4                               <- test case #2
1 2 0 0
0 0 0 0
9 4 2 0
1 7 3 0
…

[Output] 
#1 3 2 3 3 4 4 5 
#2 2 1 2 2 3
…


"""