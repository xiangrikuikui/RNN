"""
A countryhas found out that there is a spy at a broadcasting network within the country.The spy was transmitting video by inserting cryptographic codes into it. It wasfound that a code consists of numbers that indicate important facilities in thecountry. Cryptographic code rules are as follows. 
1. A code consists of 8 numbers. 
2. Seven digits in front indicate a produact’s unique number, and the last digit indicates verification code. 
- Verification code is calculated with the following method. 
“(sum of numbers in odd position x 3) + sum of numbers in even position + verification code” must be multiples of 10. 
When the product unique number is 8801234,
“( ( 8 + 0 + 2 + 4 ) x 3 ) + ( 8 + 1 + 3 ) + verification code”
= “42 + 12 + verification code”
= “54 + verification code” must be multiples of 10, the verification code must be 6. 
In other words, 88012346 is the normal cryptographic code, and if the verification code other than 6 is included, they are abnormal cryptographic codes. 

Company A istrying to develop a scanner that can recognize these cryptographic codesaccurately and fast. Performance of the scanner is measured with the followingmethods. 
1.   Cryptographic code information is contained in a rectangular array with 2,000 or less in height and 500 or less in width to be transmitted. One or more code(s) exist in one array (Note: there is no guarantee that all cryptographic codes are normal; abnormal cryptographic code(s) may be included).
2.  An array is composed of hexadecimal numbers. Convert the array to binary numbers and check the cryptographic code information within it. 
3.  Check the verification code of the cryptographic codes contained and examine whether they are normal cryptographic codes. 
4.  After discriminating normal cryptographic codes, print the sum of numbers written in these cryptographic codes. 
5. In this case, one with less time spent in total is considered as having a better performance.

Specificrules of the cryptographic codes contained in the array are as follows. 
1. A cryptographic code consists of 8 numbers and start/end distinguishing lines do not exist.  
2. There are no cases where cryptographic codes are put together (at least one empty block exists around each cryptographic code).
3. There are no cases where a cryptographic code has partial numbers marked. All cryptographic codes consist of 8 numbers. 
4. The height of a cryptographic code is 5 ~ 100 blocks. 
5. The width of a cryptographic code depends on the line thickness of the cryptographic code, and in case thickness is the thinnest, one number occupies 7 blocks. The method of expressing each numbers in figure is as follows. 
0	0 	0 	0	1 	1 	0	1 
	0 	0 	0	1 	1 	0	1 
	0 	0 	0	1 	1 	0	1 
	0 	0 	0	1 	1 	0	1 
	0 	0 	0	1 	1 	0	1 
	3 : 2 : 1 : 1
1	0	0	1	1	0	0	1
	0	0	1	1	0	0	1
	0	0	1	1	0	0	1
	0	0	1	1	0	0	1
	0	0	1	1	0	0	1
	2 : 2 : 2 : 1
2	0	0	1	0	0	1	1
	0	0	1	0	0	1	1
	0	0	1	0	0	1	1
	0	0	1	0	0	1	1
	0	0	1	0	0	1	1
	2 : 1 : 2 : 2
3	0	1	1	1	1	0	1
	0	1	1	1	1	0	1
	0	1	1	1	1	0	1
	0	1	1	1	1	0	1
	0	1	1	1	1	0	1
	1 : 4 : 1 : 1
4	0	1	0	0	0	1	1
	0	1	0	0	0	1	1
	0	1	0	0	0	1	1
	0	1	0	0	0	1	1
	0	1	0	0	0	1	1
	1 : 1 : 3 : 2
5	0	1	1	0	0	0	1
	0	1	1	0	0	0	1
	0	1	1	0	0	0	1
	0	1	1	0	0	0	1
	0	1	1	0	0	0	1
	1 : 2 : 3 : 1
6	0	1	0	1	1	1	1
	0	1	0	1	1	1	1
	0	1	0	1	1	1	1
	0	1	0	1	1	1	1
	0	1	0	1	1	1	1
	1 : 1 : 1 : 4
7	0	1	1	1	0	1	1
	0	1	1	1	0	1	1
	0	1	1	1	0	1	1
	0	1	1	1	0	1	1
	0	1	1	1	0	1	1
	1 : 3 : 1 : 2
8	0	1	1	0	1	1	1
	0	1	1	0	1	1	1
	0	1	1	0	1	1	1
	0	1	1	0	1	1	1
	0	1	1	0	1	1	1
	1 : 2 : 1 : 3
9	0	0	0	1	0	1	1
	0	0	0	1	0	1	1
	0	0	0	1	0	1	1
	0	0	0	1	0	1	1
	0	0	0	1	0	1	1
	3 : 1 : 1 : 2

Each number is expressed by ratio of area of white blocks to area of blue blocks. When the length of the cryptographic code gets longer, the length occupied by one number becomes a multiple of 7. For example, when the width increases twofold, 9 can be expressed as below. 
9	0	0	0	0	0	0	1	1	0	0	1	1	1	1
	0	0	0	0	0	0	1	1	0	0	1	1	1	1
	0	0	0	0	0	0	1	1	0	0	1	1	1	1
	0	0	0	0	0	0	1	1	0	0	1	1	1	1
	0	0	0	0	0	0	1	1	0	0	1	1	1	1
	3 : 1 : 1 : 2

6.  Minimum width of a cryptographic code is 56, and when cryptographic code line gets thicker, the length becomes a multiple of 56. For example, one cryptographic code number uses 14 blocks, the width of a cryptographic code becomes 112. Numbers contained in one cryptographic code all have the same size. 

Write aprogram that discriminates normal cryptographic codes after receiving a two-dimensionalarray that contains cryptographic code information in input. 
[Input]
T test cases are given continuously through standard input. (The code forexecuting input/output has been already provided in the template code youreceived for reference.) 
Twonatural numbers N and M are given in the first line of each test case with Nbeing the array height size and M being the array width size (1≤N<2000,1≤M<500). In the next N lines, M values of the array are given. All valuesin the array in the problem are hexadecimal numbers.  

[Output]
Print answers of each of the test cases in order through standard output, andprint “C+” at start of line for each case with C being the case number. In thesame line, leave one blank space and print the sum of numbers contained innormal cryptographic codes in the array given in input. 


[Reference]
Each test case is composed as follows (the sample input, and the input used forevaluation have the same structure).

Test case	N * M	Width of Cryptographic Code	No. of Cryptographic Code
Group 1	100 * 26	56	1
Group 2	200 * 50	56 ~ 112	2
Group 3	500 * 126	56 ~ 280	5
Group 4	1000 * 250	No limit	No limit
Group 5	2000 * 500	No limit	No limit

[Input/outputexample]
Input (example with two test cases in total. The input to be actually used hasmore test cases than the example; N and M values follow the reference above.)
2
16 26 			← N, M values, Case 1 starts
00000000000000000000000000
00000000000000000000000000
000000001DB176C588D26EC000
000000001DB176C588D26EC000
000000001DB176C588D26EC000
000000001DB176C588D26EC000
000000001DB176C588D26EC000
000000001DB176C588D26EC000
000000001DB176C588D26EC000
000000001DB176C588D26EC000
000000001DB176C588D26EC000
000000001DB176C588D26EC000
000000001DB176C588D26EC000
000000001DB176C588D26EC000
00000000000000000000000000
00000000000000000000000000


18 50 			← N, M values, Case 2 starts
00000000000000000000000000000000000000000000000000
00000000000000000000000000000000000000000000000000
000000000000000000000000000196EBC5A316C57800000000
000000000000000000000000000196EBC5A316C57800000000
000000328D1AF6E4C9BB0000000196EBC5A316C57800000000
000000328D1AF6E4C9BB0000000196EBC5A316C57800000000
000000328D1AF6E4C9BB0000000196EBC5A316C57800000000
000000328D1AF6E4C9BB0000000196EBC5A316C57800000000
000000328D1AF6E4C9BB0000000196EBC5A316C57800000000
000000328D1AF6E4C9BB0000000196EBC5A316C57800000000
000000328D1AF6E4C9BB0000000196EBC5A316C57800000000
000000328D1AF6E4C9BB0000000196EBC5A316C57800000000
000000328D1AF6E4C9BB0000000196EBC5A316C57800000000
000000328D1AF6E4C9BB0000000196EBC5A316C57800000000
000000000000000000000000000196EBC5A316C57800000000
000000000000000000000000000196EBC5A316C57800000000
00000000000000000000000000000000000000000000000000
00000000000000000000000000000000000000000000000000
Output
#1 38 
#2 48 

Explanation
Conversion of cryptographic code information of case 1 results in the following. 
01110110110001011101101100010110001000110100100110111011
01110110110001011101101100010110001000110100100110111011
01110110110001011101101100010110001000110100100110111011
01110110110001011101101100010110001000110100100110111011
01110110110001011101101100010110001000110100100110111011
01110110110001011101101100010110001000110100100110111011
01110110110001011101101100010110001000110100100110111011
01110110110001011101101100010110001000110100100110111011
01110110110001011101101100010110001000110100100110111011
01110110110001011101101100010110001000110100100110111011
01110110110001011101101100010110001000110100100110111011
01110110110001011101101100010110001000110100100110111011

The numbers above indicate the following.
0111011(7) 0110001(5) 0111011(7) 0110001(5) 0110001(5) 0001101(0) 0010011(2) 0111011(7)

To check if the verification codes is right, since (7 + 7 + 5 + 2) * 3 + 5 + 5 + 0 + 7 = 80, this is the right cryptographic code. Therefore, the output value of case 1 is 38. 

When case 2 is computed with the same method, 
328D1AF6E4C9BB becomes 14468227, so we can see the verification code is wrong. 
196EBC5A316C578 becomes 18694956, so we can see the verification code is right. 
Therefore, the output value of case 2 is 48 added only by the value of the right cryptographic code which is 18694956. 

"""