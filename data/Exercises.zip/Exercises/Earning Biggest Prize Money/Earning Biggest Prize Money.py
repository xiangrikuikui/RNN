"""
The winner in a quiz contest will be givenan opportunity to earn bonus prize money. Among the given number cards, thewinner can choose two number cards and exchange their positions as many timesas the set number.  

For example, let’s assume five numbercards 3, 2, 8, 8, 8 are given as follows and the number of exchange is set to 2.

Before exchange>
3		2		8		8		8

For a first time, positions of 3 in thefirst card and 8 in the last card were switched and the order of the cardsbecame 8, 2, 8, 8, 3. 

8		2		8		8		3

Next, positions of 2 in the second cardand 8 in the fourth card were switched and the order of the cards became 8, 8,8, 2, 3. 

8		8		8		2		3

After switch is made as many as the setnumber, prize money is calculated by the weight given to the positions of thecards. The prize money is 1 won at right end and it increases by ten times asit moves by one digit. When the order of the cards becomes 8,8,8,2,3 as shown inthe example above, the winner will get the bonus prize money of 88823 won. 

Note that switch must be made as manytimes as the set number, and the switch of the same positions switched can take place. Inthe following case, the number of exchange is set to 1, so switch must occuronce to get 49 as the result. 

9		4	Switch once->	4		9

In case of 94, when switch is madetwice, the order goes back to the original number which is 94. 

Now, compute the biggest amount ofprize money the winner can get when number cards are switched as many times asthe set number. 

[Input] 

A maximum of 10 test cases are giventhrough standard input. In the first line of each test case, case number isgiven. In the second line, the information on number cards and the number ofexchange are given. The information on the number cards will be given ininteger-type numbers, and the maximum number of digits is 6. 

[Output]
Print “#C” in the first line for eachtest case with C being the case number. Leave a blank space and print thebiggest amount of prize money the winner can receive after exchange in the sameline.

[Input/output example]
Input 

1       ← Case 1 starts 
123 1	← Information on number cards and the number of exchange
2        ← Case 2 starts
2737 1 ← Information on number cards, and the number of exchange
3
32888 2
. . .

Output
#1 321
#2 7732
#3 88832
. . .

"""