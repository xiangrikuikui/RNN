"""
You will start playing a software programming game whereyou reach target goals by solving 2 types of problems. 
1stProblem Robots stand here and there in an R*R matrix-shapedgrid. When robot A shoots a machine gun, rotating in 360°, otherrobots in his sight are all shot. But robot B is on the straight line withrobot A with robot C in-between, robot B is hidden by robot C and does not comeinto sight of robot A. As a result, robot B is not shot, when robot A shots amachine gun, In other words, when multiple robots stand on the straight line insight of robot A, the closes robot only gets shot. The figure below is oneexample of being in a 10*10 grid. Circles indicate robots and the starindicates a shooting robot, the robots colored in black do not get shot whilethe rest do. 
 
 
####pic#### 
 
Now, for each of N robots, find the number of robots thatare shot when the robot shots a machine gun while rotating in 360°, andprint out the sum of theses N numbers (first output). In this problem, therobot does not actually shoot; you find how many robots can be shot from eachrobot’s perspective. 

The function below is one for finding the minimum commondivisor of two natural numbers p and q. If you need the function below insolving the step 1 problem, use it. It does not mean you must use the function,and below is a case provided for your reference where an approach using thisfunction is being taken. 

GCD(p, q) {
if p < q then return GCD(q, p);
else if q = 0 then return p;
else return GCD(q, p mod q); // p modq means a remainder of division of p by q
}

2ndProblem. Put N numbers you get from above into the array A[1..N].In other words, A[i] refers to the number of robots getting shot by robot i.Now, you are going to do the task below using the array. Since execution timeis limited, be sure to examine characteristics of the numbers dealt with inthis problem and build a program that completes this task within the shortesttime possible. The main point of this task is to create an array A[1 ... 2N] whichis twice that of the array A[1...N] using the array A[1…N] and sort it.

for i = 1 to N {
   for j = 1 to N {
      A[j] = ((A[j] *K + j) mod N) + 1; // constant K isgiven in input
      A[N + j] =((A[j] * j + K) mod N) + 1;
   }
   sort A[1...(2*N)]in ascending order; // Array of 2*N size
   B[0] = 1; 
   for j = 1 to 2*N {
      B[j] = ((B[j-1]* A[j] + j) mod N) + 1;
   }
   C[i] = B[2*N];
}
Write the sum of all elements of C[1...N] above; // 2ndoutput

The key to this task above is sorting. Unless sorting isdone as efficiently as possible, you will not be able to handle all inputswithin the set timeframe. 

[Input]
In the first line of the input file, the number of testcases, T, is given T(1≤T≤10). From the next line, 
input for each test case is given in order. In the firstline of each test case, three natural numbers are given which are the size ofthe grid, R(5≤R≤1,000), the number of robots, N(1≤N≤5,000), the constant K(1≤K≤10,000)respectively. In the next N lines, two natural numbers greater than or equal to1, and smaller than or equal to R are given, and these are numbers of rows andcolumns occupied by each robot in the matrix. It is safe to consider there isno case where the two robots occupy the same place. Natural numbers in eachline are separated by a white space. 

[Output]
For each test case, print out the case number in the formof "#x", leave a white space and write the first and second outputscontinuously in the same line. Write the next case in the following line. 

If you are unable to find the two outputs for all inputsand solve step 1 problem only, you will get partial score.  

[Inputexample]
3
5 5 2
3 1
3 2
3 3
3 4
3 5
5 4 2
3 1
3 2
3 4
3 5
5 7 1
2 2
4 3
4 4
3 3
2 4
3 4
4 5
For the first input, the locations of each of the robots areas follows. 

				
				
1	2	3	4	5
				
				

Then, only robot 2 gets shot by robot 1’s machine gun,and robots 1 and 3 get shot by the machine fun of robot 2. Continuing solving forA like this, you will get 1, 2, 2, 2, 1 sequentially, and as a result, thefirst output is 8. Based on what’s found so far, solve for C and you will get 3,5, 1, 5, 1. Therefore, the second output is 15. 

[Output example 1]

#1 8 15 
#2 6 4 
#3 36 14 






[Output example 2] 
When you have tried up to step 1 on the same input, youwill see the following result printed. 

#1 8 
#2 6 
#3 36 
 
 

 

"""