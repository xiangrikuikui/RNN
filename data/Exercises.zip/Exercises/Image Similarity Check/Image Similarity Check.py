# -*- coding: utf-8 -*-
"""
Created on Fri Aug 31 12:00:10 2018

@author: samsung
"""

"""
We have a scanner that scans an image to return it into a 4-color (code) stream. The four colors are red(R), green(G), blue(B),and black(K). You want to check the similarity by comparing the scanned code streams of the two images. 
The scanned code streams of the two images have one of the following four states due to image deterioration: {match, mismatch, insertion, deletion}
Let’s take an example of the input of two image code streams which are X=“RBKBGRBGGG”, Y =“BGKRBRKBGB”. 
 
 【13】
 
 
We can see the number of streams that match is 6. Therefore,the similiary is 60.00% since 6 out of 10 match. 
Write a program that finds the similarity of the scanned twoimage code streams given and returns it. 
For example, in the example above, 
X’s substreams are : 
{ {R},{B},…,{BK},…,{BKB},…,{BKRBGG},…,{RBKBGRBGGG}} 
Y’s substreams are: 
{ {B},{G},…,{BK},…,{BKB},…,{BKRBGG},…,{BGKRBRKBGG}}.

Substreams in common are{{B}, …, {BK},…,{BKB},…,{BKRBGG}}.The biggest substream the two have in common is {BKRBGG} and its size is 6. 
So, the similarity in accordance with the whole size is 6(match)/10(wholesize)*100(percentage) = 60.00. 

[Input] 
The numbe of total test cases T is given in the uppermostline. From the next line, T test cases are given. Each test case is giventhrougout 3 lines; the first line of each test case has the size of the scannedimage code stream, N(provided N <= 500), and the second line has the firstcode stream X. In the third line, the second code stream Y is given. 
[Output] 
Print answers for each of T test cases line-by-line in Tlines in total. Start each line with “#x”, leave a blank space, compute thevalue of similarity of the two images given in each test case up to hundredthsplace and print it out in one line. 
 
[Input/output example]
Input( T test cases in total are given line-by-line.) 
10                                                           <- Total number of test cases T
10                                    <- 1st test case   N=10
RBKBGRBGGG                            <- 1st test case   1st 10 code streams  
BGKRBRKBGB                            <- 1st test case   2nd 10 code streams
 
 Output (consisting of T lines in total)
 
#1 60.00
…


