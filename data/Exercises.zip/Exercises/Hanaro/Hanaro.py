"""
You are going to take charge of ‘Hanaro’ – the project to design a transport system that connects N islands within Indonesia. The Hanaro project aims to reduce obstacles caused by poor connection among the islands since they undermine the development of Indonesian tourism industry, there by creating added values. The goal of this project is to connect all the islands within Indonesia through underwater tunnels. 
Underwater tunnels must connect two islands with a linesegment and even if two tunnels intersect, it is assumed the two tunnels arenot connected physically (In the case of figure 1 below, even though island Aand island D are connected, the crossing two tunnels are considered as “not connected” since it is not possible to reach from island A to island B, or to island C.  
 
   
###1### 
 
 
In the following two cases, all islands are connected. 
  
###2### 
 
You should connect the all islands within Indonesia usingthe methods above. 
As shown in figure 3, there are cases where islands are connected directly as is the case with island B and island A, but there are also cases where islands are connected indirectly through several islands as is the case with island B and C. 

The government of Indonesia has a policy as follows that makes it mandatory to pay pollution charges for environmental damage caused bythe construction of underwater tunnels. 
- Amount of payment: Pollution tax rate (E) x square of underwater tunnel length (L) = (E * L2)
Design a transport system that can connect all N islands while minimizing the total amount of pollution charges. 
If variables are not defined as 64 bit integer or double, overflow could take place. 
(In C/C++, a 64 bit integer is declared as long long.)
(You can see that all islands are connected by minimizing pollution charges in figure 2 above, but it is not the case for figure 3.)

[Input]
10 test cases are given continuously through standard input
In the first line of each test case, the number of islands N is given (1≤N≤1,000). 
In the second line, coordinates of x – the integers ofeach island- are given. In the third line, coordinates of y – the integers ofeach island- are given. (0≤X≤1,000,000, 0≤Y≤1,000,000) 
Lastly, a real number E – pollution tax rate for underwater tunnel construction – is given. (0≤E≤1)

[Output]
Print answers for each of the test cases through standardinput and print “#C” at start of line for each test case with C being the case number. In the same line, leave a blank space and print the minimum pollution charge for connecting all islands in the given input by rounding off to the nearest ones place in the form of integer. 
[Input/output example]
Input
2      ← value of N, Case 1 starts
0 0    ← X coordinates
0 100  ← Y coordinates
1.0    ← value of E
4      ← value of N, Case 2 starts
0 0 400 400
0 100 0 100
1.0
6
0 0 400 400 1000 2000
0 100 0 100 600 2000
0.3
9
567 5 45674 24 797 29 0 0 0
345352 5464 145346 54764 5875 0 3453 4545 123
0.0005
Output
#1 10000
#2 180000
#3 1125000
#4 27365366
. . .

"""