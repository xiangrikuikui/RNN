# -*- coding: utf-8 -*-
"""
Created on Fri Aug 31 11:35:34 2018

@author: samsung
"""

"""
A master artisan at a furniture manufacturing factory makes a piece of furniture in 5 minutes, but his work can have defects. We call a piece of furniture without defect a “finished product”. The head of the factory put up a competition between two master artisans. The head is curious about the possibility that at least one of the two artisans have the decimal number for the number of finished products they make. For artisans A, and B, each artisan’s probability of making a finished product in 5 minutes in usual time is given. 
skillOfMasterA is the probability artisan makes a finished product in 5 minutes, and skillOfMasterB is the probability that artisan B makes a finished product in 5 minutes. Assume each artisan can make a maximum of 1 finished product in 5 minutes. Both artisans will be given 90 minutes. Write a program that finds the probability that at least one artisan have the decimal number for the number of finished products made. 
 
 
 【19-1】
  
For example, when the probability of skillOfMasterA is 100%, and the probability of skillOfMasterB is 100%, artisan A makes 18 finished products and artisan B makes 18 finished products. Since 18 is not a decimal number, the probability of it being a decimal number is 0.0. 

[Constraints]
skillOfMasterA and skillOfMasteB are probabilities for making a finished product in 5 minutes, and the scope of the values is 0 <= skillOfMasterA, skillOfMasteB <=100. 
The competition will be held for 90 minutes. 
[Input] 
In the uppermost line, the total number of test cases T is given. From the next line, T test cases are given. Each test case is given in one line, which has an integer value (0 <= skillOfMasterA <=100) followed by an integer value (0 <= skillOfMasteB <=100) after a white space.
[Output] 
Print answers for each of T test cases line-by-line throughout T lines. Start each line with ‘#x’, leave a white space, and print the probability that at least one artisan have the decimal number for the number of finished products they make using skillOfMasterA, and skillOfMasteB given in each test case. If the number to be printed has more than 6 digits after the decimal point, round it off to the nearest millionths place. 
[Input/output example]
Input (a total of T test cases are given line-by-line.)
 
10         <- Total number of test cases T
0 0       <- 1st test case   skillOfMasterA = 0, skillOfMasteB = 0
80 90     <- 2nd test case   skillOfMasterA = 80, skillOfMasteB = 90
    
 Output(consisting of T lines in total)
#1 0.000000
#2 0.503683
…



