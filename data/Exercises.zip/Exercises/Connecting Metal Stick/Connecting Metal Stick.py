"""
You will connect circular metal sticks as longest as possible. One side ofthe circular metal stick has an external thread, and the other side has aninternal thread. The external and internal threads are different in thickness.In the figure below, thickness of the external thread is 3 while that of theinternal thread is 4. 
(Hereafter, thickness of the treads will be represented as ‘thickness ofexternal thread x thickness of internal thread’. Stick connection will be indicatedas ‘+’.)
 
 
###1### 
 
 
 
To connect such circular metal sticks, thickness of the external thread andthat of the internal thread must match. For example, when there are twocircular metal sticks A(3x4) and B(4x5), connection must be made as 3x4+4x5,and they will not get connected if the sequence is 4x5+3x4. 

###2### 
 
Now,you will connect circular metal sticks with different external and internalthread sizes as many as possible. Write a program that finds the sequence by which amaximum number of sticks are connected. 
[Input]
In the first line,the number of test cases is given. The test cases are given in each line. Eachtest case consists of 2 lines; the first line has a number of circular metalstick, n, and the next line has 2*n numbers. Numbers are separated by a blankspace. Two numbers from the front mean the thickness of the external thread,and that of the internal thread of a circular metal stick respectively.

[Output]
Print out answers foreach of the test cases. Start each line with ‘#x’, leave a blank space, andprint in order the thicknesses of the external and internal threads of circularmetal stick so that they could be connected as longest as possible from thesequence given in each test case. 

[Input/output example]
Input
 
10                              <- No. of test cases
3                             <- Test case #1,  No. of circular metal stick
3 4 2 3 4 5                     <- Matrix of thicknesses of external and internal
 threads
4                               <- Test case #2
1 2 5 1 2 4 4 3
…

[Output] 
 
#1 2 3 3 4 4 5
#2 5 1 1 2 2 4 4 3
…


"""