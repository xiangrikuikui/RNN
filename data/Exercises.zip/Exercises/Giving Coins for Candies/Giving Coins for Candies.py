"""
The head of private piano academy decided to givepraise coins to elementary school students who take piano lessons in theacademy in commemoration of Children’s Day on May 5th. So every daywhen a student did something worthy of praise, the head gave one-dime coinsticker to his students and they will be able to trade the stickers theycollect for 1 year for candy. 
To achieve more educational effect, the head cameup with an idea. Instead of giving 10 candies to the student who collected 10stickers, he will divide 10 stickers into 3 groups and give his students asmany candies as the number multiplied by the number of coins of each of the 3groups. When he divides 10 coins into 3 groups, how can he divide them so thata maximum number of candies can be given?
For example, if he divides the coins into 1, 1, and8, since 1x1x8=8, 8 candies can be given. The maximum number of candies thatcan be given is 36 since 3x3x4=36. 
 
###pic### 
 
 
Each student will have a different number ofsticker coins and the head will use different combinations of the groups. 
Write a program that finds the maximum number ofcandies that can be given when the number of dime coins and the number of coinsof each group are given. 

[Constraints]
The scope of N, the numberof coins the students at the academy collect is 10 D <= N <= 100 D.
P, the number of groups, isP <= N. 

[Input] 
In the uppermost line, the totalnumber of test cases T is given. From the next line, T test cases are given.Each test case is given in one line which has a positive integer N (the numberof coins) followed by a positive integer P (the number of groups) after a whitespace. 
[Output] 
Print out answers for each of T test cases line-by-linethroughout T lines. Start each line with ‘#x’, leave a white space, and printthe maximum number of candies that can be given using the number of coins andthe number of groups given in each test case.

[Input/output example]
Input (a total of T testcases are given line-by-line.)
 
10         <- Total number of test cases T
10 3       <- 1st test case   N = 5, P = 3
20 5       <- 2nd test case   N = 20, P = 5
    
 Output (consisting of T lines in total)
#1 36
#2 1024
…


"""