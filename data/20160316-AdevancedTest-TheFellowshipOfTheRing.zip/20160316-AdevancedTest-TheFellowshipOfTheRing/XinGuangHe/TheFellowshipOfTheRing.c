#include <stdio.h>
#include <stdlib.h>
int data[20][2];
int Answer,N;
void dazhang(int orc[],int c){
	//int temporc[4];
	if(orc[3]>=c){
		orc[0] = orc[0]-orc[3];
		orc[3] = orc[2];
		orc[2] = orc[1];
	}else if(orc[3]<c && orc[3]+orc[2]>=c){
		orc[3] = orc[2]+orc[3]-c;
		orc[2] = orc[1];
		orc[0] = orc[0]-c;
	}else{
		orc[3] = 0;
		orc[2] = orc[0]-c;
		orc[0] = orc[0]-c;
	}
	orc[1]=0;
	//return temporc;
}
void run(int orc[],int money,int n){
	int temporc[4];
	//printf("%d, %d\n",orc[0],money); 
	if(Answer<=money) return;
	if(n==N && Answer>money){
		Answer=money;
		return;
	}
	if(orc[0]>=data[n][0]){
		temporc[0] = orc[0];
		temporc[1] = orc[1];
		temporc[2] = orc[2];
		temporc[3] = orc[3];
		dazhang(temporc,data[n][0]);
		run(temporc,money,n+1);
	}
	run(orc,money+data[n][1],n+1);
	temporc[0] = orc[0]+data[n][0];
	temporc[1] = orc[1]+data[n][0];
	temporc[2] = orc[2];
	temporc[3] = orc[3];
	run(temporc,money+(2*data[n][1]),n+1);
}
int main(void)
{
	int tc, T, i;
	int orc[4];//={0,0,0,0};
	
	// The freopen function below opens input.txt file in read only mode, and afterward,
	// the program will read from input.txt file instead of standard(keyboard) input.
	// To test your program, you may save input data in input.txt file,
	// and use freopen function to read from the file when using scanf function.
	// You may remove the comment symbols(//) in the below statement and use it.
	// But before submission, you must remove the freopen function or rewrite comment symbols(//).
	
 	freopen("input.txt", "r", stdin);

	// If you remove the statement below, your program's output may not be rocorded
	// when your program is terminated after the time limit.
	// For safety, please use setbuf(stdout, NULL); statement.

	setbuf(stdout, NULL);

	scanf("%d", &T);
	//T=1;
	for(tc = 1; tc <= T; tc++)
	{
		scanf("%d", &N);
		//printf("N=%d, S=%d\n",N,S); 
		for(i=0;i<N;i++) {
			scanf("%d", &data[i][0]);
			scanf("%d", &data[i][1]);
			//printf("data[i]=%d  %d\n",data[i][0],data[i][1]); 
		}
		Answer = 99999999;
		orc[0]=orc[1]=orc[2]=orc[3]=0;
		run(orc,0,0);
		printf("#%d %d\n", tc, Answer);
	}

	return 0;//Your program should return 0 on normal termination.
}
